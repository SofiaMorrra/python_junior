side_a = int(input('please enter first side: '))
side_b = int(input('please enter second side: '))
side_c = int(input('please enter third side: '))

if (side_c ** 2 == side_a ** 2 + side_b ** 2) == 0:
    print(True)
# else side_c ** 2 != side_a ** 2 + side_b ** 2
#     print(False)