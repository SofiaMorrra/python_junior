numbers = [ '1', '2', '3', '5', '8' ]
# add_numbers = (8, 2, 5)
numbers.append('8, 2, 5')