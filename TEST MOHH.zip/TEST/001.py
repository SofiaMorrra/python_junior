
name = input('Enter your name: ')
surname = input('Enter your surname: ')
age = input('Enter your age: ')
print('Hello, ' + surname.title() + ' ' + name.title() + '. Your age is ' + age)