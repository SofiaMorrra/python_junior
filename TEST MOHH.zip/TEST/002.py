

side_a = float(input('please enter first side: '))
side_b = float(input('please enter second side: '))
side_c = str(float((side_a ** 2 + side_b ** 2) ** 0.5))
print(side_c)
print('Hypotenuse is ' + side_c + ' cm.')
