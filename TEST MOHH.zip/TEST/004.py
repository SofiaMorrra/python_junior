
list = input("please write words: ").split()

print(list)
print(list.reverse())

