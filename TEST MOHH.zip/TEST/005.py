tuple_a = (1, 2, 3, 5, 8)
tuple_b = (8, 2, 5)
tuple_ab = tuple_a + tuple_b
